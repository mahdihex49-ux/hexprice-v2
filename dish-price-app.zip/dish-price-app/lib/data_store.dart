import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';

import 'config.dart';
import 'models.dart';

/// نگهداری و به‌روزرسانی لیست قیمت‌ها:
/// ۱) آخرین نسخه‌ی ذخیره‌شده روی گوشی (یا فایل داخل برنامه) فوری نمایش داده میشه
/// ۲) نسخه‌ی جدید از گیت‌هاب گرفته میشه و برای دفعه‌های بعد ذخیره میشه
class DataStore {
  static const String _cacheName = 'prices_cache.csv';

  static Future<File> _cacheFile() async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/$_cacheName');
  }

  /// آخرین نسخه‌ی ذخیره‌شده، وگرنه نسخه‌ی داخل برنامه
  static Future<String> loadLocal() async {
    try {
      final f = await _cacheFile();
      if (await f.exists()) {
        final t = await f.readAsString();
        if (t.trim().isNotEmpty) return t;
      }
    } catch (_) {}
    return rootBundle.loadString('assets/prices.csv');
  }

  static Future<void> save(String text) async {
    try {
      final f = await _cacheFile();
      await f.writeAsString(text);
    } catch (_) {}
  }

  /// آدرس‌ها به ترتیب: اول فایل data_urls.txt داخل برنامه، آخرش گیت‌هاب
  static Future<List<String>> _urls() async {
    final urls = <String>[];
    try {
      final raw = await rootBundle.loadString('assets/data_urls.txt');
      for (final line in raw.split('\n')) {
        final u = line.trim();
        if (u.isEmpty || u.startsWith('#')) continue;
        urls.add(u);
      }
    } catch (_) {}
    if (!kDataUrl.contains('__REPO__') && !urls.contains(kDataUrl)) {
      urls.add(kDataUrl);
    }
    return urls;
  }

  /// گرفتن فایل از اولین آدرسی که فایل سالم بده؛ اگه هیچ‌کدوم جواب نداد null
  static Future<String?> fetchRemote() async {
    for (final url in await _urls()) {
      final text = await _get(url);
      if (text != null && Catalog.tryParse(text) != null) return text;
    }
    return null;
  }

  static Future<String?> _get(String url) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 8);
    try {
      final sep = url.contains('?') ? '&' : '?';
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final req = await client.getUrl(Uri.parse('$url${sep}t=$stamp'));
      final res = await req.close().timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) return null;
      return await res
          .transform(utf8.decoder)
          .join()
          .timeout(const Duration(seconds: 20));
    } catch (_) {
      return null;
    } finally {
      client.close(force: true);
    }
  }
}
