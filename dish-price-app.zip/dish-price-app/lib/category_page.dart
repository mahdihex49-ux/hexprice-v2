import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'models.dart';
import 'style.dart';
import 'widgets.dart';

enum SortMode { original, cheap, expensive, alpha }

class CategoryPage extends StatefulWidget {
  const CategoryPage({
    super.key,
    required this.catalog,
    required this.category,
  });

  final Catalog catalog;
  final Category category;

  @override
  State<CategoryPage> createState() => _CategoryPageState();
}

class _CategoryPageState extends State<CategoryPage> {
  final TextEditingController _ctrl = TextEditingController();
  String _q = '';
  SortMode _sort = SortMode.original;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  List<Item> _visible() {
    final tokens = queryTokens(_q);
    final list = widget.category.items
        .where((it) => tokens.isEmpty || it.matches(tokens))
        .toList();
    switch (_sort) {
      case SortMode.original:
        break;
      case SortMode.cheap:
        list.sort((a, b) {
          if (a.price == 0 && b.price != 0) return 1;
          if (b.price == 0 && a.price != 0) return -1;
          return a.price.compareTo(b.price);
        });
        break;
      case SortMode.expensive:
        list.sort((a, b) => b.price.compareTo(a.price));
        break;
      case SortMode.alpha:
        list.sort((a, b) => compareFa(a.name, b.name));
        break;
    }
    return list;
  }

  Widget _chip(String label, SortMode mode) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: _sort == mode,
        onSelected: (_) => setState(() => _sort = mode),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final g = gradientFor(widget.category.index);
    final items = _visible();

    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        title: Text(
          widget.category.name,
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.centerRight,
              end: Alignment.centerLeft,
              colors: g,
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
            child: TextField(
              controller: _ctrl,
              onChanged: (v) => setState(() => _q = v),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'جستجو در ${widget.category.name}…',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _q.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _ctrl.clear();
                          setState(() => _q = '');
                        },
                      ),
                filled: true,
                fillColor: Color.alphaBlend(g[0].withAlpha(20), cs.surface),
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _chip('پیش‌فرض', SortMode.original),
                _chip('ارزان‌ترین', SortMode.cheap),
                _chip('گران‌ترین', SortMode.expensive),
                _chip('الفبا', SortMode.alpha),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 4),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                '${toFaDigits('${items.length}')} کالا',
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
              ),
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? Center(
                    child: Text(
                      'موردی پیدا نشد',
                      style: TextStyle(color: cs.onSurfaceVariant),
                    ),
                  )
                : ListView.builder(
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
                    itemCount: items.length,
                    itemBuilder: (context, i) => ItemTile(
                      catalog: widget.catalog,
                      item: items[i],
                      number: _q.isEmpty && _sort == SortMode.original
                          ? i + 1
                          : null,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
