import 'package:flutter/material.dart';

/// رنگ هر لیست (به ترتیب لیست‌ها در برنامه)
const List<List<Color>> kGradients = [
  [Color(0xFF0F766E), Color(0xFF14B8A6)], // طرح
  [Color(0xFFB45309), Color(0xFFF59E0B)], // رنگ ترنج
  [Color(0xFFBE185D), Color(0xFFF472B6)], // طرح گل و مرغ
  [Color(0xFF7E22CE), Color(0xFFC084FC)], // رنگ گل و مرغ
  [Color(0xFF1D4ED8), Color(0xFF60A5FA)], // تاچ گل و مرغ
  [Color(0xFFB91C1C), Color(0xFFF87171)], // تشعیر
  [Color(0xFF4338CA), Color(0xFF818CF8)], // قلم گیری تشعیر
  [Color(0xFF0369A1), Color(0xFF38BDF8)], // آبرنگ تشعیر
  [Color(0xFF475569), Color(0xFF94A3B8)], // سایه تشعیر
  [Color(0xFF15803D), Color(0xFF4ADE80)], // گره
  [Color(0xFFC2410C), Color(0xFFFB923C)], // بندکشی
  [Color(0xFFA16207), Color(0xFFFACC15)], // ورق طلا
  [Color(0xFF9D174D), Color(0xFFFB7185)], // قاب
];

const List<IconData> kIcons = [
  Icons.draw,
  Icons.palette,
  Icons.local_florist,
  Icons.format_paint,
  Icons.brush,
  Icons.auto_awesome,
  Icons.edit,
  Icons.water_drop,
  Icons.layers,
  Icons.link,
  Icons.border_all,
  Icons.star,
  Icons.filter_frames,
];

List<Color> gradientFor(int index) => kGradients[index % kGradients.length];

IconData iconFor(int index) => kIcons[index % kIcons.length];

ThemeData buildTheme(Brightness brightness) {
  final scheme = ColorScheme.fromSeed(
    seedColor: const Color(0xFF0F766E),
    brightness: brightness,
  );
  final light = brightness == Brightness.light;
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor:
        light ? const Color(0xFFF3F6F7) : const Color(0xFF0E1417),
  );
}
