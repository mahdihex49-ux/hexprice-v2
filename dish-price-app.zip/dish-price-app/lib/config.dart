/// آدرس فایل قیمت‌ها روی گیت‌هاب.
/// موقع ساخت APK روی گیت‌هاب، __REPO__ و __BRANCH__ خودکار با اسم مخزن شما جایگزین میشن.
const String kDataUrl =
    'https://raw.githubusercontent.com/__REPO__/__BRANCH__/prices.csv';
