import 'package:flutter/material.dart';

import 'models.dart';
import 'style.dart';

/// قیمت با واحد (برای ردیف لیست)
class PriceLabel extends StatelessWidget {
  const PriceLabel({super.key, required this.price});

  final int price;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    if (price <= 0) {
      return Text(
        'بدون قیمت',
        style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
      );
    }
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          formatPrice(price),
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: cs.primary,
          ),
        ),
        Text(
          kUnit,
          style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant),
        ),
      ],
    );
  }
}

/// یک ردیف کالا در لیست
class ItemTile extends StatelessWidget {
  const ItemTile({
    super.key,
    required this.catalog,
    required this.item,
    this.number,
    this.showCategory = false,
  });

  final Catalog catalog;
  final Item item;
  final int? number;
  final bool showCategory;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final g = gradientFor(item.category.index);
    final base = Color.alphaBlend(g[0].withAlpha(18), cs.surface);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: base,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => showItemSheet(context, catalog, item),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: g),
                  ),
                  child: number != null
                      ? Text(
                          toFaDigits('$number'),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                          ),
                        )
                      : Icon(
                          iconFor(item.category.index),
                          color: Colors.white,
                          size: 20,
                        ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        toFaDigits(item.name),
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: cs.onSurface,
                        ),
                      ),
                      if (showCategory)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            item.category.name,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: g[0],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                PriceLabel(price: item.price),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// برگه‌ی جزئیات کالا (قیمت + قیمت همین ظرف در لیست‌های دیگه)
void showItemSheet(BuildContext context, Catalog catalog, Item item) {
  final others = catalog.othersWithSameName(item)
    ..sort((a, b) => a.category.index.compareTo(b.category.index));
  final g = gradientFor(item.category.index);

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
    ),
    builder: (ctx) {
      final cs = Theme.of(ctx).colorScheme;
      return SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerRight,
                  end: Alignment.centerLeft,
                  colors: g,
                ),
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withAlpha(51),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      item.category.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    toFaDigits(item.name),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (item.price > 0)
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          formatPrice(item.price),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Text(
                            kUnit,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    )
                  else
                    const Text(
                      'قیمت ثبت نشده',
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('کد کالا',
                      style: TextStyle(color: cs.onSurfaceVariant)),
                  Text(toFaDigits(item.code),
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            if (others.isNotEmpty) ...[
              const Divider(height: 24, indent: 20, endIndent: 20),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                child: Text(
                  'قیمت همین ظرف در لیست‌های دیگه',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: cs.onSurface,
                  ),
                ),
              ),
              for (final o in others)
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                  child: Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: gradientFor(o.category.index)[0],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: Text(o.category.name)),
                      Text(
                        o.price > 0
                            ? '${formatPrice(o.price)} $kUnit'
                            : 'بدون قیمت',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
            ],
            const SizedBox(height: 28),
          ],
        ),
      );
    },
  );
}
